#music app by ashwin tiwary
import tkinter as tk
from tkinter import *
import pygame
from PIL import ImageTk

pygame.mixer.init()    
def light():
   pygame.mixer.music.load("lights_theme.mp3")
   pygame.mixer.music.play(loops=999999)

     
def L():
   pygame.mixer.music.load("l_theme_death_note.mp3")
   pygame.mixer.music.play(loops=999999)

def ryuk():
    pygame.mixer.music.load("ryuk.mp3")
    pygame.mixer.music.play(loops=999999)

def intro():
    pygame.mixer.music.load("deathnote.mp3")
    pygame.mixer.music.play(loops=999999)

def aria():
    pygame.mixer.music.load("c418_aria_math_slowed.mp3")
    pygame.mixer.music.play(loops=999999)

def stop():
    pygame.mixer.music.stop()
    
def hadal():
    pygame.mixer.music.load("hadal_ahbek.mp3")
    pygame.mixer.music.play(loops=999999)

def cheri():
    pygame.mixer.music.load("cheri_cheri_lady.mp3")
    pygame.mixer.music.play(loops=999999)

def runaway():
    pygame.mixer.music.load("runaway.mp3")
    pygame.mixer.music.play(loops=999999)

def depressed():
    pygame.mixer.music.load("cute_depressed.mp3")
    pygame.mixer.music.play(loops=999999)

def fantasma():
    pygame.mixer.music.load("phonk_fantasma.mp3")
    pygame.mixer.music.play(loops=999999)

def bad_parenting():
    pygame.mixer.music.load("bad_parenting_funk.mp3")
    pygame.mixer.music.play(loops=999999)
def other():
    root = tk.Tk()
    root.config(bg="#000000")
    root.title("other songs")
    tk.Button(root, text="play bad parenting", command=bad_parenting, bg="#ffffff").pack()
    tk.Button(root, text="play fantasma", command=fantasma, bg="#ffffff").pack()
    tk.Button(root, text="play cute depressed", command=depressed, bg="#ffffff").pack()
    root.mainloop()
app = tk.Tk()
app.title("music app")

app.config(bg="#000000")

tk.Label(app, text=" DEATH NOTE MUSIC APP", fg="#ffffff", bg="#000000").pack(pady=5)

jk = ImageTk.PhotoImage(file="L image.jpg")
tk.Button(app, image=jk).pack(pady=5)

tk.Button(app, text="play L theme", bg="#ffffff", command=L).pack()

tk.Button(app, text="play Light's theme", bg="#ffffff", command=light).pack()

tk.Button(app, text="play intro music", bg="#ffffff", command=intro).pack()

tk.Button(app, text="play ryuk theme", bg="#ffffff", command=ryuk).pack()

tk.Button(app, text="play aria math", bg="#ffffff", command=aria).pack()

tk.Button(app, text="play hadal ahbek", bg="#ffffff", command=hadal).pack()

tk.Button(app, text="play cheri cheri lady", bg="#ffffff", command=cheri).pack()

tk.Button(app, text="play runaway", bg="#ffffff", command=runaway).pack()

tk.Button(app, text="other songs", command=other, bg="#ffffff").pack()

tk.Button(app, text="stop music", bg="#ffffff", command=stop).pack()

app.mainloop()