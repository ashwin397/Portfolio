import tkinter as tk
from tkinter import *
from tkinter import messagebox
import pygame

pygame.mixer.init()    
def ashwin():
   pygame.mixer.music.load("birthday.mp3")
   pygame.mixer.music.play(loops=9999)
def stop():
    pygame.mixer.music.stop()

bday = Tk()
bday.title("happy birthday ashwin")
bday.config(bg="#6100b3")
tk.Label(bday, text="HAPPY BIRTHDAY ASHWIN TIWARY", fg="#ffffff", bg="#6100b3"). pack()
tk.Button(bday, text="play birthday song", command=ashwin).pack(pady=5)
tk.Button(bday, text="stop music", command=stop).pack(pady=5)
tk.Button(bday, text="Exit", command=bday.destroy).pack(pady=5)
bday.mainloop()