#death note fanbase app developed by ashwin tiwary

import tkinter as tk
from tkinter import *
from tkinter import messagebox
from tkinter import simpledialog
import time
from PIL import ImageTk
import pygame

pygame.mixer.init()    
def play():
   pygame.mixer.music.load("lights_theme.mp3")
   pygame.mixer.music.play(loops=999999)

def about():
    tk.messagebox.showinfo(title="about", message="This app is developed by ashwin tiwary")

def Rule():
    root = tk.Tk()
    root.title("rules to use death note")
    root.config(bg="#000000")
    headings = tk.Label(root, text="HOW TO USE?", fg="#ffffff", bg="#000000")
    headings.pack(padx=245)
    q = tk.Label(root, text="○the humans name written shall die", fg="#ffffff", bg="#000000")
    q.pack()
    o = tk.Label(root, text="", fg="#ffffff", bg="#000000")
    o.pack()
    w = tk.Label(root, text="○after writing name person will die after 40 sec", fg="#ffffff", bg="#000000")
    w.pack()
    i = tk.Label(root, text="", fg="#ffffff", bg="#000000")
    i.pack()
    e = tk.Label(root, text="○if you don't know person's face it won't work", fg="#ffffff", bg="#000000")
    e.pack()
    r = tk.Label(root, text="to avoid people with same name", fg="#ffffff", bg="#000000")
    r.pack()
    u = tk.Label(root, text="", fg="#ffffff", bg="#000000")
    u.pack()
    t = tk.Label(root, text="○if cause of death not mentioned person will die", fg="#ffffff", bg="#000000")
    t.pack()
    y = tk.Label(root, text="of heart attack", fg="#ffffff", bg="#000000")
    y.pack()
    p = tk.Label(root, text="", fg="#ffffff", bg="#000000")
    tk.Button(root, text="about", bg="#ffffff", command=about).pack()
    p.pack(pady=450)
    root.mainloop()


    
def input_get():
    global i
    i = tk.Entry.get(input)
    screen.after(400)
    if i == "shinigami king":
        tk.messagebox.showwarning(title="Ryuk speaking", message="shinigami king is angry")
        tk.messagebox.showwarning(title="shinigami king", message=" face concequences")
        tk.messagebox.showinfo(title="Ryuk", message="you died of heart attack tap ok to revive")
        pygame.mixer.music.load("ryuk.mp3")
        pygame.mixer.music.play(loops=999999)
        tk.messagebox.showinfo(title="ryuk speaking", message="now you are surviving on my heart kira")
        
    
    elif i == "rem":
        tk.messagebox.showinfo(title="Ryuk speaking", message="you can't kill shinigami")
    
    
    elif i == "ryuk":
        tk.messagebox.showinfo(title="Ryuk speaking", message="you can't kill shinigami")
    
    elif i == kira:
        tk.messagebox.showinfo(title="Ryuk speaking", message="you can't kill yourself")
    else:
        tk.messagebox.showinfo(title="kill succesful", message=i+" died of heart attack")
        global r
        r = i
        


def name():
    global screen
    screen = tk.Tk()
    screen.title("write name")
    screen.config(bg="#000000")
    headings = tk.Label(screen, text="WRITE NAMES", fg="#ffffff", bg="#000000")
    headings.pack(padx=245)
    global input
    input = tk.Entry(screen)
    input.pack()
    h = tk.Button(screen, text="kill", bg="#000000", fg="#ffffff", command=input_get)
    h.pack()
    screen.mainloop()

def kill():
    jk = tk.Tk()
    jk.title("kills")
    jk.config(bg="#000000")
    tk.Label(jk, text=r, fg="#ffffff", bg="#000000").pack()
    jk.mainloop()

page = tk.Tk()
page.title("death note")
page.config(bg="#000000")
play()
tk.messagebox.showinfo(title="WELCOME", message="welcome to death note fanbase app")
global kira
kira = simpledialog.askstring("kira", "enter your name kira", parent=page)
title = tk.Label(page, text="DEATH NOTE", fg="#ffffff", bg="#000000")
title.pack()

rule_button = tk.Button(page, bg="#ffffff",  text="Rules", command=Rule)
rule_button.pack(pady=10)

name_button = tk.Button(page, bg="#ffffff", text="write name", command=name)
name_button.pack(pady=10)

tk.Button(page, text="last kill", command=kill, bg="#ffffff").pack()

jk = ImageTk.PhotoImage(file="L image.jpg")
tk.Label(page, image=jk).pack()

page.mainloop()