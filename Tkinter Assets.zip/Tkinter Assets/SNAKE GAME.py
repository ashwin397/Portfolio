#THIS CODE IS MADE BY ASHWIN TIWARY


#importing modules
import tkinter as tk
from tkinter import *
import time
import random


#apple position
applex=random.randint(10,300)
appley=random.randint(10,500)


#change in position of apple
def change():
    applex=random.randint(10,300)
    appley=random.randint(10,500)
    apple.place(x=applex, y=appley)
    


#help feature
def change_window():
    root = tk.Tk()
    Label(root, text="SNAKE GAME").pack()
    Label(root, text="by ashwin tiwary").pack()
    Label(root, text="to control snake click on it").pack()
    Label(root, text="press u for up, d for down, l for left, r for right").pack()
    Label(root, text="after you reach apple press change apple position and go to that where the apple is").pack()
    Label(root, text="enjoy :)").pack()
    root.mainloop



#movement of snake
def UP(event):
    label.place(x=label.winfo_x(), y=label.winfo_y()-10)
 
def left(event):
    label.place(x=label.winfo_x()-10, y=label.winfo_y())

def DOWN(event):
    label.place(x=label.winfo_x(), y=label.winfo_y()+10)

def right(event):
    label.place(x=label.winfo_x()+10, y=label.winfo_y())



#designing window
screen = tk.Tk()
screen.config(bg="#03ff00")
title = tk.Label(screen, text="WELCOME TO SNAKE GAME")


#generating apple
apple = tk.Label(screen, width=1, height=1, bg="red")
apple.place(x=applex, y=appley)
title.pack()

#making snake movement
screen.bind("<u>", UP)
screen.bind("<d>", DOWN)
screen.bind("<r>", right)
screen.bind("<l>", left)


#generating snake
label = tk.Entry(screen, text="main character", bg="blue")
label.place(x=0, y=200)


#making buttons
button = tk.Button(screen, text="change apple position", command=change)
button.pack()
button2 = tk.Button(screen, text="help", command=change_window)
button2.pack()

screen.mainloop()

#the end