import tkinter as tk
from tkinter import *
import pygame
from PIL import ImageTk

pygame.mixer.init()
def lose():
    lose = tk.Tk()
    lose.title("i win")
    lose.config(bg="#000000")
    pygame.mixer.music.load("light_yagamis_laugh.mp3")
    pygame.mixer.music.play(loops=1)
    lose.mainloop()

kira = tk.Tk()
kira.config(bg="#000000")
tk.Label(kira, text="kira", fg="#ffffff", bg="#000000").pack()
tk.Button(kira, text="evil laugh", fg="#ffffff", bg="#000000", command=lose).pack(pady=5)
kira.mainloop()