import tkinter as tk
from tkinter import *
from tkinter import messagebox
from PIL import ImageTk
import time
def virus():    
    z = tk.Label(window, text="downloaded MyDoom virus")
    z.pack()
    time.sleep(3)
    i = tk.messagebox.showwarning(title="tor:-darkweb.onion", message="MyDoom virus installed succesfully")
    while True:
        spam = tk.Label(window, text="MyDoom!!")
        spam.pack()
        j = tk.messagebox.showwarning(title="MyDoom!!", message="MyDoom spam")
        while True:
            x = 22
            print("MyDoom")
            print(x/7)
            pass
        

window = tk.Tk()
tk.Label(window, text="MY LOTTERY APP!!").pack()
tk.Label(window, text="enter your address").pack()
tk.Entry(window).pack()
clickme = tk.Button(window, text="win lottery!!", command=virus)
clickme.pack()
window.mainloop()