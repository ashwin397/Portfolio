import tkinter as tk
from tkinter import *
from tkinter import messagebox

def aone():
    motivation1 = tk.messagebox.showinfo(title="motivation", message="i know you can study show study what you really are!!")

def btwo():
    motivation2 = tk.messagebox.showinfo(title="motivation", message="they bully you? huh, you beat them and bully them!!")

def cthree():
    motivation3 = tk.messagebox.showinfo(title="motivation", message="they don't respect you because you seek for attention and think about the.")

def dfour():
    motivation4 = tk.messagebox.showinfo(title="motivation", message="you are bankrupt then i have nothing for you :) :)")

def efive():
    motivation5 = tk.messagebox.showinfo(title="motivation", message="sucide is not an option")

def fsix():
    motivation6 = tk.messagebox.showinfo(title="motivation", message="drink water after waking up")

def gseven():
    motivation7 = tk.messagebox.showinfo(title="motivation", message="take some time to fix your phone addiction and be raedy to learn.")



app = tk.Tk()
app.title("motivational app")
app.config(bg="#ffffff")


headings = tk.Label(app, text="MOTIVATIONAL APP", bg="#ffffff")
headings.pack(pady=10)

headings = tk.Label(app, text="what is your problem?", bg="#ffffff")
headings.pack(pady=10)

a = tk.Button(app, text="i can't study", command=aone)
a.pack(pady=5)

b = tk.Button(app, text="everyone bullies me", command=btwo)
b.pack(pady=5)

c = tk.Button(app, text="others don't respect me", command=cthree)
c.pack(pady=5)

d = tk.Button(app, text="i am bankrupt", command=dfour)
d.pack(pady=5)

e = tk.Button(app, text="i am feeling sucidal", command=efive)
e.pack(pady=5)

f = tk.Button(app, text="i have no motivation for gym", command=fsix)
f.pack(pady=6)

g = tk.Button(app, text="i can't learn something new", command=gseven)
g.pack(pady=7)

app.mainloop()