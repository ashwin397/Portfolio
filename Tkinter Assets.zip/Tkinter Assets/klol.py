import pygame
pygame.mixer.init()
pygame.mixer.music.load("lights_theme.mp3")
pygame.mixer.music.play(loops=999999)