"""
hello guys today I am making an app for my birthday
wish me happy birthday 20th January 2012
"""
import tkinter as tk
from tkinter import *
from PIL import ImageTk
from tkinter import messagebox

def ol():
    j = tk.Button(bday, text="unubscribed", command=L, fg="#ffffff", bg="#ff0000").place(x=250, y=150)
    messagebox.showinfo(title="please", message="please don't unsubscribe")

def L():
    j = tk.Button(bday, text="Subscribed  ", command=ol).place(x=250, y=150)
    messagebox.showinfo(title="thanks", message="thanks for subscribing")

def n():
    k = tk.Button(bday, text="Subscribe  ", command=L, bg="#ff0000", fg="#ffffff").place(x=250, y=150)
    messagebox.showinfo(title="welcome", message="welcome to my channel")

bday = tk.Tk()
jk = ImageTk.PhotoImage(file="Ashar.jpg")
tk.Button(bday, image=jk).pack()
tk.Label(bday, text="ASHAR ANIMATION AND CODE").place(x=150, y=90)
n()
p = tk.Button(bday, text="Exit", command=bday.destroy).place(x=300, y=250)
bday.mainloop()